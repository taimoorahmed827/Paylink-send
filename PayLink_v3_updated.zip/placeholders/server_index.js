// server/index.js - placeholder
console.log('PayLink server placeholder - replace with real backend');
