
PayLink_v3_updated - README (Urdu / English)

---
Admin account aur initialization:
- Admin Account Number: PL-2244-10000001-2
- Transfer PIN (temporary, secure): 524549
- Email corrected to: ta7014176@gmail.com
- Password (initial): tai583611

Important security note:
- PIN aur password sirf initialization ke liye plain rakhe gaye hain.
- Production me inko hashed values se replace karain (bcrypt/argon2 recommended).
- 2FA enabled hai; admin ko login ke baad PIN change karna chahiye.

Mobile (Expo) setup (short):
1. Install Node.js and Expo CLI: `npm install -g expo-cli`
2. Copy this project folder to your machine.
3. Place `default_admin.json` in the project root (already included).
4. Run `expo start` and open app in Expo Go on mobile or emulator.

Laptop (Full project) setup (short):
1. Backend: `server/` folder (placeholder). Create .env with DB settings and point to default_admin.json for initial admin seed.
2. Frontend: `web/` folder (placeholder). Replace default_admin.json if needed.
3. Run `npm install` in each folder and `npm run dev` (or follow your existing build scripts).

Files included in this ZIP:
- default_admin.json        -> Admin initialization data (Urdu labels included)
- project_skeleton.json     -> Describes included skeleton and where to paste files
- README.txt                -> This file (Urdu/English)
- placeholders/             -> Basic placeholder files for App.js server/index.js and web index.html

---
Generated at: 2025-10-14T14:53:54.263511Z
